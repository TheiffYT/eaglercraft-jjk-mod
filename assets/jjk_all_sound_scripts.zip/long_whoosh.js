
function onUse(player, world, x, y, z) {
  player.playSound("long_whoosh", 1.0, 1.0);
  player.setCooldown("long_whoosh", 20);
}

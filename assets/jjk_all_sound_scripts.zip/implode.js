
function onUse(player, world, x, y, z) {
  player.playSound("implode", 1.0, 1.0);
  player.setCooldown("implode", 20);
}


function onUse(player, world, x, y, z) {
  player.playSound("clap2", 1.0, 1.0);
  player.setCooldown("clap2", 20);
}

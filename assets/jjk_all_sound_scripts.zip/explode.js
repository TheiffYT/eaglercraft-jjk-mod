
function onUse(player, world, x, y, z) {
  player.playSound("explode", 1.0, 1.0);
  player.setCooldown("explode", 20);
}


function onUse(player, world, x, y, z) {
  player.playSound("snap", 1.0, 1.0);
  player.setCooldown("snap", 20);
}

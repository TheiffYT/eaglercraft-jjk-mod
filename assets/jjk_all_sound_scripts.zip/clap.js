
function onUse(player, world, x, y, z) {
  player.playSound("clap", 1.0, 1.0);
  player.setCooldown("clap", 20);
}

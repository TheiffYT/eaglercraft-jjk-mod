
function onUse(player, world, x, y, z) {
  player.playSound("spirit_sound9", 1.0, 1.0);
  player.setCooldown("spirit_sound9", 20);
}


function onUse(player, world, x, y, z) {
  player.playSound("whoosh_hit", 1.0, 1.0);
  player.setCooldown("whoosh_hit", 20);
}

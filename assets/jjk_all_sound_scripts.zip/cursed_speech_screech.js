
function onUse(player, world, x, y, z) {
  player.playSound("cursed_speech_screech", 1.0, 1.0);
  player.setCooldown("cursed_speech_screech", 20);
}

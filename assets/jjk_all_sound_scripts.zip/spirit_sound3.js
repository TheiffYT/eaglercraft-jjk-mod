
function onUse(player, world, x, y, z) {
  player.playSound("spirit_sound3", 1.0, 1.0);
  player.setCooldown("spirit_sound3", 20);
}

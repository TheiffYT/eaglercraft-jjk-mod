
function onUse(player, world, x, y, z) {
  player.playSound("cinematic_whoosh", 1.0, 1.0);
  player.setCooldown("cinematic_whoosh", 20);
}

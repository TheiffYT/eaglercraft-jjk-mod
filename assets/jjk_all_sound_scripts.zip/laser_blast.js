
function onUse(player, world, x, y, z) {
  player.playSound("laser_blast", 1.0, 1.0);
  player.setCooldown("laser_blast", 20);
}

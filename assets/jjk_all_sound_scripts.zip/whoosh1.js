
function onUse(player, world, x, y, z) {
  player.playSound("whoosh1", 1.0, 1.0);
  player.setCooldown("whoosh1", 20);
}

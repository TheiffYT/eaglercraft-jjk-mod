
function onUse(player, world, x, y, z) {
  player.playSound("black_flash_impact", 1.0, 1.0);
  player.setCooldown("black_flash_impact", 20);
}


function onUse(player, world, x, y, z) {
  player.playSound("sizzle", 1.0, 1.0);
  player.setCooldown("sizzle", 20);
}

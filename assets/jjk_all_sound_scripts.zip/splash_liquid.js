
function onUse(player, world, x, y, z) {
  player.playSound("splash_liquid", 1.0, 1.0);
  player.setCooldown("splash_liquid", 20);
}

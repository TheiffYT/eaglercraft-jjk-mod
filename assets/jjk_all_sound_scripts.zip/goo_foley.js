
function onUse(player, world, x, y, z) {
  player.playSound("goo_foley", 1.0, 1.0);
  player.setCooldown("goo_foley", 20);
}


function onUse(player, world, x, y, z) {
  player.playSound("spirit_scream", 1.0, 1.0);
  player.setCooldown("spirit_scream", 20);
}


function onUse(player, world, x, y, z) {
  world.spawnParticle("purple_boom", x, y + 1, z, 0.2, 0.5, 0.2, 0.01, 15);
  player.playSound("purple_boom", 1.0, 1.0);
  player.setCooldown("purple_boom", 20);
}


function onUse(player, world, x, y, z) {
  world.spawnParticle("bloom_", x, y + 1, z, 0.2, 0.5, 0.2, 0.01, 15);
  player.playSound("bloom_", 1.0, 1.0);
  player.setCooldown("bloom_", 20);
}

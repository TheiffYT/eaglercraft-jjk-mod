
function onUse(player, world, x, y, z) {
  world.spawnParticle("blue_spark", x, y + 1, z, 0.2, 0.5, 0.2, 0.01, 15);
  player.playSound("blue_spark", 1.0, 1.0);
  player.setCooldown("blue_spark", 20);
}

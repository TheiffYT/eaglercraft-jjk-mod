
function onUse(player, world, x, y, z) {
  world.spawnParticle("blood_splash", x, y + 1, z, 0.2, 0.5, 0.2, 0.01, 15);
  player.playSound("blood_splash", 1.0, 1.0);
  player.setCooldown("blood_splash", 20);
}
